# Crop and Fertilizer Recommendation System

This project predicts suitable crops and recommends fertilizers based on soil and weather data.

## Features
1. **Crop Recommendation**: Predicts the best-suited crop using Random Forest.
2. **Fertilizer Recommendation**: Calculates nutrient requirements for soil.

## Files
- `data/crop_recommendation.csv`: Dataset for training the crop prediction model.
- `src/main.py`: Main script to run the system.
- `src/crop_recommendation.py`: Handles crop prediction using machine learning.
- `src/fertilizer_recommendation.py`: Provides fertilizer recommendations.

## Usage
1. Install requirements:
   ```bash
   pip install -r requirements.txt
   ```
2. Run the main script:
   ```bash
   python src/main.py
   ```

## Requirements
- Python 3.7+
- Libraries: pandas, scikit-learn, numpy
