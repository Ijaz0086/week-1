from crop_recommendation import crop_recommendation_model
from fertilizer_recommendation import recommend_fertilizer

def main():
    print("Welcome to the Crop and Fertilizer Recommendation System!")
    print("--------------------------------------------------------")
    
    # Example user input for prediction
    soil_data = {
        'N': 40,  # Nitrogen level
        'P': 50,  # Phosphorus level
        'K': 30,  # Potassium level
        'temperature': 26.5,  # in Celsius
        'humidity': 80,  # in percentage
        'ph': 6.5,  # Soil pH
        'rainfall': 200  # in mm
    }
    
    # Crop Recommendation
    crop = crop_recommendation_model(soil_data)
    print(f"Recommended Crop: {crop}")
    
    # Fertilizer Recommendation
    fertilizer_suggestion = recommend_fertilizer(soil_data['N'], soil_data['P'], soil_data['K'])
    print(f"Fertilizer Recommendation: {fertilizer_suggestion}")

if __name__ == "__main__":
    main()
