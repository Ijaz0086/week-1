import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import pickle

def crop_recommendation_model(soil_data):
    # Load the dataset
    data = pd.read_csv('../data/crop_recommendation.csv')

    # Features and Target
    X = data[['N', 'P', 'K', 'temperature', 'humidity', 'ph', 'rainfall']]
    y = data['label']

    # Train-Test Split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Model Training
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)

    # Save the trained model for reuse
    with open('../model/crop_model.pkl', 'wb') as file:
        pickle.dump(model, file)

    # Predict using the trained model
    input_data = [soil_data['N'], soil_data['P'], soil_data['K'], soil_data['temperature'], 
                  soil_data['humidity'], soil_data['ph'], soil_data['rainfall']]
    crop_prediction = model.predict([input_data])
    return crop_prediction[0]
