def recommend_fertilizer(N, P, K):
    optimal_levels = {'N': 120, 'P': 60, 'K': 40}  # Example optimal levels
    recommendations = {
        'N': max(0, optimal_levels['N'] - N),
        'P': max(0, optimal_levels['P'] - P),
        'K': max(0, optimal_levels['K'] - K),
    }
    return recommendations
